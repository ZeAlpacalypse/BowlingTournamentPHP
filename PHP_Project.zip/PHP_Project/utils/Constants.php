<?php
class Constants
{
    public static $MYSQL_CONNECTION_STRING = "mysql:host=localhost;dbname=gameCatalog";
    public static $MYSQL_USERNAME = "eanderson";
    public static $MYSQL_PASSWORD = "MySQL";
}
